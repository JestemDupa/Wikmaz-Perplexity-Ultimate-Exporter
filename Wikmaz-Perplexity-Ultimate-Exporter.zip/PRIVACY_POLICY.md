# Privacy Policy for Wikmaz - Perplexity Ultimate Export

**Effective Date:** June 3, 2026

## 1. Introduction
This Privacy Policy applies to the "Wikmaz - Perplexity Ultimate Export" browser extension (the "Extension") developed by **Wikmaz**. We believe in absolute data privacy. This document explains what data the Extension accesses and how it is handled.

## 2. Data Collection & Usage
**We do not collect, store, or transmit any of your personal data.** The Extension operates entirely locally on your machine. It is designed to extract your own chat history from Perplexity.ai and save it directly to your local hard drive. 
* **No Telemetry:** We do not track your usage, clicks, IP address, or browsing habits.
* **No External Servers:** Your exported data is never routed through, or stored on, any third-party servers belonging to the developer. It goes straight from Perplexity to your disk.

## 3. Permissions Explained
To function correctly, the Extension requires specific browser permissions. Here is exactly why we need them:
* **`activeTab` & `tabs`:** To verify that you are currently on the Perplexity.ai website before initiating the export process.
* **`scripting`:** To execute the background script that securely fetches your chat metadata.
* **`downloads`:** To automatically save the generated Markdown (`.md`) files directly to your local `Downloads` folder.
* **`host_permissions` (`*://*.perplexity.ai/*`):** To allow the Extension to authenticate with the Perplexity API using your existing, active session and retrieve your chat history.

## 4. Third-Party Services
The Extension interacts exclusively with **Perplexity.ai** to retrieve your data. Your use of Perplexity.ai is governed by their own Privacy Policy and Terms of Service. We are not affiliated with Perplexity AI.

## 5. Changes to this Policy
If we make changes to this Privacy Policy (for example, if new features require different permissions), we will update the "Effective Date" at the top of this document. Since we do not collect your contact information, we encourage you to review this policy periodically on our GitHub repository.

## 6. Contact
If you have any questions or concerns about your privacy regarding this Extension, please reach out via our official channels:
* **GitHub:** [@JestemDupa](https://github.com/JestemDupa)
* **Website:** [www.wikmaz.pl](https://wikmaz.pl)
